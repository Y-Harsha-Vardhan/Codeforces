#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

bool check(ll x, int n, vector<ll> a){
    vector<ll> d(n);
    ll acc = 0;

    for(int i=0; i<n; i++){
        acc -= d[i];
        ll need = max(0LL, i-(n-x));
        if(acc < need) return false;
        ll end = i + a[i] + (acc++) - need + 1;
        if(end < n) ++d[end]; 
    }
    return true;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<ll> a(n);
        for (ll& x : a) cin >> x;

        ll l=1, r=n+1, mid;
        while (r-l>1){
            mid = (l+r)/2;
            if(check(mid, n, a)) l=mid;
            else r=mid;
        }
        cout << l << "\n";
    }
}