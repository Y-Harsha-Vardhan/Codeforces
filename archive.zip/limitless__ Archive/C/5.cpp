#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    string s; cin >> s;
    int n = s.size();
    vector<int> dp(n);
    for (int i = n - 2; i >= 0; i--) {
        if (s[i] == '(') {
            int j = i + 1 + dp[i + 1];
            if (j < n && s[j] == ')') {
                dp[i] = dp[i + 1] + 2;
                if (j + 1 < n) dp[i] += dp[j + 1];
            }
        }
    }
    int maxLen = 0;
    for (int i = 0; i < n; ) {
        if (dp[i] > 0) {
            maxLen = max(maxLen, dp[i]);
            i += dp[i];
        } else {
            i++;
        }
    }
    int countMax = 0;
    for (int i = 0; i < n; ) {
        if (dp[i] > 0) {
            if (dp[i] == maxLen) countMax++;
            i += dp[i];
        } else {
            i++;
        }
    }
    int t;
    if (maxLen == 0 || countMax == 1) t = 1;
    else t = countMax;
    cout << maxLen << " " << t;
}
