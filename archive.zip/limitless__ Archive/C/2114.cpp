#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<int> a(n);
        int last = -1, ans = 0;
        for(int i=0; i<n; i++){
            int a; cin >> a;
            if (a - last > 1) {ans++; last = a;}
        }
        cout << ans << "\n";
    }
}