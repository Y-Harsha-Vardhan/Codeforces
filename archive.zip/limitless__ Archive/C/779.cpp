#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n,k; cin >> n >> k;
    vector<int> a(n), b(n);
    for (int& x : a) cin >> x;
    for (int& y : b) cin >> y;

    vector<pair<int,int>> v; int ans=0;
    for (int i=0; i<n; i++){
        if (a[i]<=b[i]) {ans+=a[i]; k--;}
        else {v.push_back(make_pair(a[i]-b[i],i));} 
    }

    if (k>0) sort(v.begin(), v.end());
    int j = v.size();
    for (int i=0; i<j; i++) {
        int p = v[i].second;
        if (k>0) {ans+=a[p]; k--;}
        else {ans+=b[p];}
    }

    cout << ans;
}