#include <iostream>
#include <vector>
#include <algorithm>

void solve() {
    int n;
    std::cin >> n;
    std::vector<int> d_val(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> d_val[i];
    }
    std::vector<int> l(n), r(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> l[i] >> r[i];
    }

    std::vector<long long> dp_min(n + 1);
    std::vector<long long> dp_max(n + 1);

    dp_min[0] = 0;
    dp_max[0] = 0;

    for (int i = 1; i <= n; ++i) {
        long long prev_min_h = dp_min[i - 1];
        long long prev_max_h = dp_max[i - 1];

        if (prev_min_h > prev_max_h) {
            std::cout << -1 << std::endl;
            return;
        }

        long long cand_min_h, cand_max_h;
        if (d_val[i - 1] == 0) {
            cand_min_h = prev_min_h;
            cand_max_h = prev_max_h;
        } else if (d_val[i - 1] == 1) {
            cand_min_h = prev_min_h + 1;
            cand_max_h = prev_max_h + 1;
        } else {
            cand_min_h = prev_min_h;
            cand_max_h = prev_max_h + 1;
        }

        dp_min[i] = std::max(cand_min_h, (long long)l[i - 1]);
        dp_max[i] = std::min(cand_max_h, (long long)r[i - 1]);

        if (dp_min[i] > dp_max[i]) {
            std::cout << -1 << std::endl;
            return;
        }
    }

    for (int i = n - 1; i >= 0; --i) {
        long long min_h_i_plus_1 = dp_min[i + 1];
        long long max_h_i_plus_1 = dp_max[i + 1];

        if (min_h_i_plus_1 > max_h_i_plus_1) {
            std::cout << -1 << std::endl;
            return;
        }

        long long min_h_i_needed, max_h_i_needed;
        if (d_val[i] == 0) {
            min_h_i_needed = min_h_i_plus_1;
            max_h_i_needed = max_h_i_plus_1;
        } else if (d_val[i] == 1) {
            min_h_i_needed = min_h_i_plus_1 - 1;
            max_h_i_needed = max_h_i_plus_1 - 1;
        } else {
            min_h_i_needed = min_h_i_plus_1 - 1;
            max_h_i_needed = max_h_i_plus_1;
        }

        dp_min[i] = std::max(dp_min[i], min_h_i_needed);
        dp_max[i] = std::min(dp_max[i], max_h_i_needed);

        if (dp_min[i] > dp_max[i]) {
            std::cout << -1 << std::endl;
            return;
        }
    }

    if (dp_min[0] > 0 || dp_max[0] < 0) {
        std::cout << -1 << std::endl;
        return;
    }

    std::vector<int> ans_d(n);
    long long current_h = 0;

    for (int k = 0; k < n; ++k) {
        if (d_val[k] != -1) {
            ans_d[k] = d_val[k];
        } else {
            bool can_use_1 = (dp_min[k + 1] <= current_h + 1 && current_h + 1 <= dp_max[k + 1]);
            if (can_use_1) {
                ans_d[k] = 1;
            } else {
                ans_d[k] = 0;
            }
        }
        current_h += ans_d[k];
        if (current_h < dp_min[k + 1] || current_h > dp_max[k + 1]) {
            std::cout << -1 << std::endl;
            return;
        }
    }

    for (int k = 0; k < n; ++k) {
        std::cout << ans_d[k] << (k == n - 1 ? "" : " ");
    }
    std::cout << std::endl;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}