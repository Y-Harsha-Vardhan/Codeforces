#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

bool sameParity(const vector<ll>& v) {
    int parity = v[0] % 2;
    for (ll num : v) {
        if (num % 2 != parity)
            return false;
    }
    return true;
}

ll solve(vector<ll> a){
    int n = a.size(), k=0;
    ll mx = *max_element(a.begin(), a.end());
    ll sum = accumulate(a.begin(), a.end(), 0LL);
    for (ll x : a) if (x%2 ==1 ) k++;
    if(sameParity(a)) return mx;
    else return (sum-k+1);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<ll> a(n);
        for (ll& x : a) cin >> x;
        cout << solve(a) << "\n";
    }
}