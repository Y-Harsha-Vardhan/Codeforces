#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<int> a(n);
        for (int& x : a) cin >> x;
        
        int ans=0;
        set<int> cur, seen;
        for(int i=0; i<n; i++){
            cur.insert(a[i]);
            seen.insert(a[i]);
            if(cur.size() == seen.size()){
                ans++;
                seen.clear();
            }
        }
        cout << ans << '\n';
    }
}