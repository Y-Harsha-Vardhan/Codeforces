#include <bits/stdc++.h>
using namespace std;

int solve(int n, int k, vector<int> a, vector<int> b){
    auto it = find_if(b.begin(), b.end(), [](int x) { return x != -1; });
    if (it != b.end()){
        int s = *it + a[it-b.begin()];
        for(int i=0;i<n;i++){
            if ((b[i]!=-1) && (a[i]+b[i]!=s)) return 0;
            if ((b[i]==-1) && (s-a[i]>k)) return 0;   
            if ((b[i]==-1) && (a[i]>s)) return 0;
        }
        return 1;
    }
    else {
        int mx = *max_element(a.begin(),a.end());
        int mn = *min_element(a.begin(),a.end());
        return (mn+k-mx+1);
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t; cin >> t;
    while(t--){
        int n, k; cin >> n >> k;
        vector<int> a(n), b(n);
        for (int& x : a) cin >> x;
        for (int& x : b) cin >> x;
        cout << solve(n,k,a,b) << "\n";
    }
}