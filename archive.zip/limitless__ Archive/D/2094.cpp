#include <bits/stdc++.h>
using namespace std;

bool checkValid(string s, string l) {
    char x = s[0], y = l[0];
    int a = s.size(), b = l.size(); 
    if (x!=y || a>b || b>2*a) return false;
    return true;
}

vector<string> splitContiguous(string s){
    vector<string> result;
    regex re("(R+|L+)");
    auto begin = sregex_iterator(s.begin(), s.end(), re);
    auto end = sregex_iterator();

    for(sregex_iterator i = begin; i!=end; i++) result.push_back((*i).str());
    return result;
}

void solve(string s, string l){
    int m = s.size(), n = l.size();
    if( m>n || n>2*m || s[0]!=l[0] ) {cout << "NO\n"; return;}
    vector<string> splitS = splitContiguous(s);
    vector<string> splitL = splitContiguous(l);
    if (splitS.size()!=splitL.size()) {cout << "NO\n"; return;}
    int a = splitS.size();
    for (int i=0; i<a; i++) {
        if(!checkValid(splitS[i],splitL[i])) {cout << "NO\n"; return;}
    }
    cout << "YES\n"; 
    return;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        string s, l;
        cin >> s >> l;
        solve(s,l);
    }
}