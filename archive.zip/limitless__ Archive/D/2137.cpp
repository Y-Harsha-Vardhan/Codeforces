#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<int> b(n);
        for(int &x : b) cin >> x;
        map<int, vector<int>> m;
        for(int i=0; i<n; i++) m[b[i]].push_back(i);
        vector<int> a(n, -1);
        int l = 1;
        bool valid = true;

        for(auto &p : m){
            int f = p.first;
            vector<int> arr = p.second;
            int size = arr.size();

            if (size%f != 0) { valid = false; break;}

            for (int i=0; i<size; i++) a[arr[i]] = l + i/f;
            l += size/f;
        }

        if(!valid) cout << -1 << "\n";
        else {
            for(int x : a) cout << x << " ";
            cout << "\n";
        }
    }
}
