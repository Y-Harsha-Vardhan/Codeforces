#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n; ll k; cin >> n >> k;
    vector<ll> a(n);
    ll ans=0, carry=0;
    for(int i=0; i<n; i++){
        cin >> a[i];
        ll p = a[i]+carry;
        if (p>=k) {ans+=p/k; carry=p%k;}
        else{
            if(p>0) {
                if (carry>0) {ans++; carry=0;}
                else {carry=a[i];} 
            }
        }
    }
    if (carry!=0) {if (carry<k) ans++; if(carry%k==0) ans+=carry/k;}
    cout << ans;
}