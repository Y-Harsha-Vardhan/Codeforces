#include <iostream>
#include <vector>
#include <algorithm>

void solve() {
    int n;
    std::cin >> n;
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }

    if (n == 1) {
        std::cout << 0 << std::endl;
        return;
    }

    int min_total_operations = n - 1;

    for (int i = 0; i < n; ++i) {
        int val1 = a[i];
        for (int j = 0; j < n; ++j) {
            int val2 = a[j];
            int current_min_candidate = std::min(val1, val2);
            int current_max_candidate = std::max(val1, val2);

            if ((current_min_candidate + current_max_candidate) % 2 == 0) {
                int elements_kept_count = 0;
                for (int k = 0; k < n; ++k) {
                    int element_in_original_array = a[k];
                    if (current_min_candidate <= element_in_original_array && element_in_original_array <= current_max_candidate) {
                        elements_kept_count++;
                    }
                }
                int num_ops_for_this_choice = n - elements_kept_count;
                min_total_operations = std::min(min_total_operations, num_ops_for_this_choice);
            }
        }
    }
    std::cout << min_total_operations << std::endl;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int num_test_cases;
    std::cin >> num_test_cases;
    while (num_test_cases--) {
        solve();
    }
    return 0;
}
