#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, res = 1;
    string s;
    cin >> n >> s;
    for(int i = 1; i < n; i++){
        res += (s[i] != s[i - 1]);
    }
    cout << min(res + 2, n) << '\n';
}