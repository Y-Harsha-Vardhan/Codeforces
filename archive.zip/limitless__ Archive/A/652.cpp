#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int h1,h2,a,b,ans;
    cin >> h1 >> h2 >> a >> b;
    if(h1+8*a >= h2) {cout << 0; return 0;}
    else if(a<=b) {cout << -1; return 0;}
    else {
        int x = h2-h1-8*a, y = 12*(a-b);
        ans = (x+y-1)/y;
    }
    cout << ans;
}