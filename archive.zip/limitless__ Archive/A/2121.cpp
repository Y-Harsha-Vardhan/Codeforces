#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n, s; cin >> n >> s;
        vector<int> a(n);
        for (int& x : a) cin >> x;
        int m = a[0], M = a[n-1];
        if (s<=m && s<=M) {cout << (M-s) << "\n"; continue;}
        if (s>=m && s>=M) {cout << (s-m) << "\n"; continue; }
        if (m <=s && s<=M ) {
            int a = s-m; int b = M-s;
            if (a < b) {cout << 2*(s-m)+(M-s) << "\n"; continue;}
            else {cout << (s-m) + 2*(M-s) << "\n"; continue;}
        }
    }
}