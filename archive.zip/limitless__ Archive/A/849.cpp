#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n; cin >> n;
    vector<int> a(n);
    for (int& x : a) cin >> x;

    if ((n%2==0)||(a[0]%2==0)||(a[n-1]%2==0)) cout << "No\n";
    else cout << "Yes\n";
}