#include <bits/stdc++.h>
using namespace std;

void solve(string s, char c){
    int n = s.length();
    vector<int> pos;
    for(int i=0; i<n; i++){
        if (s[i]==c) {
            if(i%2==0) {cout << "YES\n"; return;}
        }
    }
    cout << "NO\n"; 
    return;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        string s; char c;
        cin >> s >> c;
        solve(s,c);
    }
}