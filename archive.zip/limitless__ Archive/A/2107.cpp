#include<iostream>
#include<vector>
#include<numeric>
using namespace std;

// int gcd(int a, int b){
//     while(b){
//         a = b;
//         b = a%b; 
//     }
//     return a;
// }

void solve(int a, vector<int> arr){
    if (a==2){
        if (arr[0] == arr[1]) cout << "No\n";
        else cout << "Yes\n" << "1 2\n";
        return;
    }

    int g = arr[0];
    for (int x : arr) g = gcd(g,x);

    for(int i=0;i<a;i++){
        if (arr[i]!=g) {
            cout << "Yes\n";
            vector<int> ans(a,1);
            ans[i]=2;
            for(int x : ans) cout << x << " ";
            cout << "\n";
            return;
        }
    }
    cout << "No\n";
}

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        int a;
        cin >> a;
        vector<int> arr(a);
        for (int& x : arr) cin >> x;
        solve(a, arr);
    }

}