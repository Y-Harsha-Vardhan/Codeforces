#include <bits/stdc++.h>
using namespace std;

int solve(vector<int> a){
    int n = a.size();
    int ans = 0;
    for (int x : a){
        if (x == 0) ans ++;
        else ans += x;
    }
    return ans;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        vector<int> a(n);
        for (int &x : a) cin >> x;
        cout << solve(a) << "\n";
    }
}