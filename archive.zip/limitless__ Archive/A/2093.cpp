#include <bits/stdc++.h>
using namespace std;

void solve(int n){  
    if (n%2==0) {cout << "NO\n"; return;}
    else {cout << "YES\n"; return;}
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        solve(n);
    }
}