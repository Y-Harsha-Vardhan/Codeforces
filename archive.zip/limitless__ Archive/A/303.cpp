#include <bits/stdc++.h>
using namespace std;

bool isCoprime(int a,int b){
    return gcd(a,b)==1;
}

vector<int> genPerm(int n, int k){
    vector<int> perm(n);
    for(int i=0;i<n;i++) perm[i]=(k*i)%n;
    return perm;
}

void solve(int n){
    int a = -1, b = -1;

    for(int i=1; i<n; i++){
        if(!isCoprime(i, n)) continue;
        for(int j=i+1; j<n; j++){
            if(!isCoprime(j, n)) continue;

            int s = (i + j) % n;
            if(!isCoprime(s, n)) continue;
            if(s == i || s == j) continue;

            a = i;
            b = j;

            goto generate;
        }
    }

    if (n==1) goto generate;
    cout << -1 << "\n";
    return;

generate:
    vector<int> P = genPerm(n, a);
    vector<int> Q = genPerm(n, b);
    vector<int> R = genPerm(n, (a + b) % n);

    for(int x : P) cout << x << " ";
    cout << "\n";
    for(int x : Q) cout << x << " ";
    cout << "\n";
    for(int x : R) cout << x << " ";
    cout << "\n";

    return;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    if (t % 2 == 0) cout << -1 << "\n";
    else solve(t);
}
