#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int W=0, B=0;
    for (int i=0; i<8; i++){
        string s; cin >> s;
        for (char x : s) {
            if (x=='.'||x=='K'||x=='k') continue;
            if (x=='Q') W+=9; if (x=='R') W+=5; if (x=='B'||x=='N') W+=3; if (x=='P') W+=1;
            if (x=='q') B+=9; if (x=='r') B+=5; if (x=='b'||x=='n') B+=3; if (x=='p') B+=1;
        }
    }
    if (W==B) cout << "Draw";
    else (W>B)?cout << "White":cout << "Black";
}