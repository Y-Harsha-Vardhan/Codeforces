#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    string ch;
    stack<char> s;
    cin >> ch;

    int n = ch.size();
    if (n%2 == 1) {cout << "No"; return 0;}

    int a=0, b=0;
    
    for(int i=0; i<n; i++) {
        char x = ch[i];
        if (i%2 == 1) {if (x == '-') ch[i] = 'B'; else ch[i] = 'A';} 
        else {if (x == '-') ch[i] = 'A'; else ch[i] = 'B';}
        
        if (ch[i] == 'A') a++; else b++; 
    }

    if (a == b) cout << "Yes";
    else cout << "No";
}