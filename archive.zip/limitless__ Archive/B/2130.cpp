#include <bits/stdc++.h>
using namespace std;

void solve(vector<int> a, int s){
    int n = a.size();
    int sum = 0; map<int, int> num;
    for (int x : a) {
        sum += x;
        num[x]++;
    }
    if (sum > s) {for (int x : a) cout << x << " "; return;}
    if (sum == s) {cout << -1; return;}
    if (sum < s) {
        int d = s - sum;
        if (d != 1) {cout << -1; return;}
        else {
            int a = num[0], b = num[1], c = num[2];
            for (int i=0; i<a; i++) cout << 0 << " ";
            for (int i=0; i<c; i++) cout << 2 << " ";
            for (int i=0; i<b; i++) cout << 1 << " ";
            return;
        }
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n,s; cin >> n >> s;
        vector<int> a(n);
        for(int &x : a) cin >> x;
        solve(a,s);
        cout << "\n";
    }
}