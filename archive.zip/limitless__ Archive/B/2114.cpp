#include <bits/stdc++.h>
using namespace std;
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        int n,k; cin >> n >> k;
        string s; cin >> s;
        int sum = 0;
        for(int i=0; i<n; i++){
            if (s[i]=='1') sum+=1;
        }
        int x = sum - (n/2 - k);
        if (x >= 0 && x <= k*2 && x%2==0) cout << "YES\n";
        else cout << "NO\n";
    }
}