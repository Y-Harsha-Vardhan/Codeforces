#include <iostream>
#include <vector>
using namespace std;

using ll = long long;

ll pow2(int exp) {
    if (exp >= 63) return 1LL << 62; 
    return 1LL << exp;
}

ll ceil_div(ll a, ll b) {
    if (a == 0) return 0;
    return (a + b - 1) / b;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        ll x;
        int n, m;
        cin >> x >> n >> m;

        ll min_stage = ceil_div(x, pow2(m));
        ll min_val = min_stage / pow2(n);

        ll max_stage = x / pow2(n);
        ll max_val = ceil_div(max_stage, pow2(m));

        cout << min_val << " " << max_val << "\n";
    }
}
