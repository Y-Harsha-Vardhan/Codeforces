#include <iostream>
#include <string>
#include <vector>

void solve() {
    std::string s;
    std::cin >> s;
    int n = s.length();

    int balance = 0;
    bool decomposable = false;

    for (int i = 0; i < n; ++i) {
        if (s[i] == '(') {
            balance++;
        } else {
            balance--;
        }
        if (balance == 0 && i < n - 1) {
            decomposable = true;
            break;
        }
    }

    if (decomposable) {
        std::cout << "YES" << std::endl;
    } else {
        std::cout << "NO" << std::endl;
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
