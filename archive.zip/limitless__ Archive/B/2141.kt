fun main() = repeat(readln().toInt()) {
  val (n, m) = readln().split(" ").map { it.toInt() }
  val a = readln().split(" ").map { it.toInt() }
  val b = readln().split(" ").map { it.toInt() }
  val k = a.intersect(b).size
  println(2 * minOf(n - k, m - k) + if (n > m) 2 else 1)
}