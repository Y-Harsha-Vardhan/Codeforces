#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

bool isPerfect(ll N) { 
    if ((sqrt(N) - floor(sqrt(N))) != 0) return false; 
    return true; 
} 

ll findsqrt(ll n) {
    while(n) {
        if(isPerfect(n)) return n;
        n--;
    }
    
    return 1;
}

int main() {
    ll n; cin>>n;
    ll x = sqrt(findsqrt(n));
    ll ans = x*4;
    ll extra = n - (x*x);
    if(extra>0) {
        if(extra<=x) ans+=2;
        else ans+=4;
    }
     
    cout<<ans<<endl;
     
}