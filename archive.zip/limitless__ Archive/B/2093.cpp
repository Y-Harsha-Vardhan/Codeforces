#include <bits/stdc++.h>
using namespace std;

void solve(string s){
    int n = s.length();
    if(n==1) {cout << 0 << "\n"; return;}
    int x=0,i;
    for (i=n-1; i>=0; i--) if (s[i]!='0') {x++; break;}
    for (int j = i-1; j>=0; j--) if (s[j]=='0') {x++;}
    cout << n-x << "\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t--){
        string s; cin >> s;
        solve(s);
    }
}