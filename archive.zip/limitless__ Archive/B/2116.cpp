#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5, MOD = 998244353;
int n, s[N], p[N], q[N];

inline void solve() {
    cin >> n;
    for (int i = 0; i < n; i++) cin >> p[i];
    for (int i = 0; i < n; i++) cin >> q[i];

    int i = 0, j = 0;
    for (int k = 0; k < n; k++) {
        if (p[k] > p[i]) i = k;
        if (q[k] > q[j]) j = k;

        if (p[i] != q[j]) {
            if (p[i] > q[j]) {
                cout << (s[p[i]] + s[q[k - i]]) % MOD << " ";
            } else {
                cout << (s[q[j]] + s[p[k - j]]) % MOD << " ";
            }
        } else {
            cout << (s[p[i]] + s[max(q[k - i], p[k - j])]) % MOD << " ";
        }
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    for (int i = 0; i < N; i++) {
        s[i] = (i == 0) ? 1 : (s[i - 1] * 2LL) % MOD;
    }

    int t;
    cin >> t;
    while (t--) solve();

    return 0;
}