import kotlin.math.max
import kotlin.math.min

fun main() {
    val t = readln().toInt()

    repeat(t) {
        val (a, b, c, d) = readln().split(" ").map { it.toLong() }
        val ans = (c - a) + (d - b) - max(0L, min(c, d) - max(a, b))
        println(ans)
    }
}