#include <bits/stdc++.h>
using namespace std;

void solve(int n, int a, int b) {
    if (a + b > n - 2 || abs(a - b) > 1) {
        cout << "-1\n";
        return;
    }

    vector<int> res;
    if (a > b) {
        int low = 1;
        int high = n;
        int remaining = n - (a + b + 1);

        for (int i = 0; i < remaining; ++i) {
            res.push_back(low++);
        }

        bool peak = true;
        for (int i = 0; i < a + b + 1; ++i) {
            if (peak) {
                res.push_back(high--);
            } else {
                res.push_back(low++);
            }
            peak = !peak;
        }
    } else if (b > a) {
        int low = 1;
        int high = n;
        int remaining = n - (a + b + 1);

        for (int i = 0; i < remaining; ++i) {
            res.push_back(high--);
        }

        bool valley = true;
        for (int i = 0; i < a + b + 1; ++i) {
            if (valley) {
                res.push_back(low++);
            } else {
                res.push_back(high--);
            }
            valley = !valley;
        }
    } else {
        int low = 1;
        int high = n;
        int remaining = n - (a + b + 1);

        for (int i = 0; i < remaining; ++i) {
            res.push_back(low++);
        }

        bool peak = true;
        for (int i = 0; i < a + b + 1; ++i) {
            if (peak) {
                res.push_back(high--);
            } else {
                res.push_back(low++);
            }
            peak = !peak;
        }
    }

    for (int x : res) {
        cout << x << " ";
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        int n, a, b;
        cin >> n >> a >> b;
        solve(n, a, b);
    }
    return 0;
}