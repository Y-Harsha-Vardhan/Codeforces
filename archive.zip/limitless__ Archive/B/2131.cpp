#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    vector<int> nums(t);
    for (int &x : nums) cin >> x;
    for (int i=0; i<t; i++) {
        int n = nums[i];
        for (int i=0; i<n; i++) {
            if (i%2 == 0) cout << "-1 ";
            else {
                if (i == n-1) cout << "2 ";
                else cout << "3 ";
            }
        }
        cout << "\n";
    }
}